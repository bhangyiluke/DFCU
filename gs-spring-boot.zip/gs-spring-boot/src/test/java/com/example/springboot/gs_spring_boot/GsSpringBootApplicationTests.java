package com.example.springboot.gs_spring_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GsSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}

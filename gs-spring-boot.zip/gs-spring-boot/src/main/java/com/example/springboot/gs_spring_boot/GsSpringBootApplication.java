package com.example.springboot.gs_spring_boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GsSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(GsSpringBootApplication.class, args);
	}

}
